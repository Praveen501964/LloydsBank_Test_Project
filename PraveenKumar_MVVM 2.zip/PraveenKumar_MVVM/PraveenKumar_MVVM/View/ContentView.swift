//
//  ContentView.swift
//  PraveenKumar_MVVM
//
//  Created by 1976969 on 23/07/25.
//

import SwiftUI

struct ContentView: View {

    var body: some View {
        // Calling the List view defined from the custom view for not breaking the raw logic
        CustomerListView()
    }
}

